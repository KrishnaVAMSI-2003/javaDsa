import java.util.Scanner;

public class Question3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String str = sc.nextLine();
        String chStr = sc.next();
        System.out.println(str.replace(chStr,""));
    }
}
